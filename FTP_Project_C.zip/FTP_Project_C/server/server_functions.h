// server_functions.h

#ifndef SERVER_FUNCTIONS_H
#define SERVER_FUNCTIONS_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stdio.h>  // For FILE type

#define BUFFER_SIZE 1024
#define SERVER_DIR "/Users/kennytohme/Documents/UNI/Computer Programming Y2Q1/FTP_Project_C/server"

// Function declarations
void upload_file(int client_socket);
void download_file(int client_socket);
int read_line(int socket, char *buffer, int size);
int read_line_file(FILE *fp, char *buffer, int size);
void list_files(int client_socket);
void handle_client(int client_socket);

#ifdef __cplusplus
}
#endif

#endif // SERVER_FUNCTIONS_H
