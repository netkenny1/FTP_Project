// server.h

#ifndef SERVER_H
#define SERVER_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stdio.h>  // Include necessary headers

// Function declarations
int read_line(int socket, char *buffer, int size);
int read_line_file(FILE *fp, char *buffer, int size);
// Other function declarations as needed

#ifdef __cplusplus
}
#endif

#endif // SERVER_H
