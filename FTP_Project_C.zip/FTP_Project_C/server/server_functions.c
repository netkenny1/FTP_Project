// server_functions.c

#include "server_functions.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <dirent.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <errno.h>

// Function to read a line from the socket
int read_line(int socket, char *buffer, int size) {
    int total_bytes = 0;
    while (total_bytes < size - 1) {
        char c;
        int bytes_received = recv(socket, &c, 1, 0);
        if (bytes_received <= 0) {
            if (total_bytes == 0) {
                return bytes_received;
            } else {
                break;
            }
        }
        if (c == '\n') {
            break;
        }
        buffer[total_bytes++] = c;
    }
    buffer[total_bytes] = '\0';
    return total_bytes;
}

// Function to read a line from a file
int read_line_file(FILE *fp, char *buffer, int size) {
    int total_bytes = 0;
    while (total_bytes < size - 1) {
        int c = fgetc(fp);
        if (c == EOF) {
            if (total_bytes == 0) {
                return -1; // No data read
            } else {
                break; // End of file
            }
        }
        if (c == '\n') {
            break; // End of line
        }
        buffer[total_bytes++] = (char)c;
    }
    buffer[total_bytes] = '\0';
    return total_bytes;
}

// Function to send the list of files to the client
void list_files(int client_socket) {
    DIR *dir;
    struct dirent *entry;
    char buffer[BUFFER_SIZE] = {0};

    dir = opendir(SERVER_DIR);
    if (dir == NULL) {
        strcpy(buffer, "Error: Unable to open directory.\n");
        send(client_socket, buffer, strlen(buffer), 0);
        return;
    }

    while ((entry = readdir(dir)) != NULL) {
        if (entry->d_name[0] != '.') { // Ignore hidden files
            strcat(buffer, entry->d_name);
            strcat(buffer, "\n");
        }
    }
    closedir(dir);

    if (strlen(buffer) == 0) {
        strcpy(buffer, "No files found in the directory.\n");
    }

    send(client_socket, buffer, strlen(buffer), 0);
}

// Function to handle file uploads from the client
void upload_file(int client_socket) {
    char filename[BUFFER_SIZE] = {0};
    char filepath[BUFFER_SIZE] = {0};
    char buffer[BUFFER_SIZE] = {0};
    int file;

    // Receive the filename from the client
    if (read_line(client_socket, filename, BUFFER_SIZE) <= 0) {
        printf("DEBUG: Failed to receive filename\n");
        return;
    }
    printf("DEBUG: Receiving file: %s\n", filename);

    // Receive the file size
    char filesize_str[BUFFER_SIZE] = {0};
    if (read_line(client_socket, filesize_str, BUFFER_SIZE) <= 0) {
        printf("DEBUG: Failed to receive file size\n");
        return;
    }
    long filesize = atol(filesize_str);
    printf("DEBUG: File size: %ld bytes\n", filesize);

    snprintf(filepath, sizeof(filepath), "%s/%s", SERVER_DIR, filename);

    // Open the file for writing
    file = open(filepath, O_WRONLY | O_CREAT | O_TRUNC, 0666);
    if (file < 0) {
        perror("DEBUG: Error creating file");
        strcpy(buffer, "Error: Unable to create file.\n");
        send(client_socket, buffer, strlen(buffer), 0);
        return;
    }
    printf("DEBUG: File opened for writing: %s\n", filepath);

    // Receive the file data from the client
    long total_bytes_received = 0;
    while (total_bytes_received < filesize) {
        int bytes_to_read = BUFFER_SIZE;
        if (filesize - total_bytes_received < BUFFER_SIZE) {
            bytes_to_read = filesize - total_bytes_received;
        }
        int bytes_received = recv(client_socket, buffer, bytes_to_read, 0);
        if (bytes_received <= 0) {
            printf("DEBUG: Connection closed or error\n");
            break;
        }
        write(file, buffer, bytes_received);
        total_bytes_received += bytes_received;
        printf("DEBUG: Writing %d bytes to %s\n", bytes_received, filepath);
    }

    close(file);

    // Send confirmation to the client
    strcpy(buffer, "File uploaded successfully.\n");
    send(client_socket, buffer, strlen(buffer), 0);
    printf("DEBUG: Sent confirmation for file: %s\n", filename);
}

// Function to handle file downloads to the client
void download_file(int client_socket) {
    char filename[BUFFER_SIZE] = {0};
    char filepath[BUFFER_SIZE] = {0};
    char buffer[BUFFER_SIZE] = {0};
    int file;

    // Receive the filename from the client
    if (read_line(client_socket, filename, BUFFER_SIZE) <= 0) {
        printf("DEBUG: Failed to receive filename\n");
        return;
    }
    printf("DEBUG: Client requested file: %s\n", filename);

    snprintf(filepath, sizeof(filepath), "%s/%s", SERVER_DIR, filename);

    // Open the file for reading
    file = open(filepath, O_RDONLY);
    if (file < 0) {
        perror("DEBUG: Error opening file");
        strcpy(buffer, "Error: File not found.\n");
        send(client_socket, buffer, strlen(buffer), 0);
        return;
    }
    printf("DEBUG: File opened for reading: %s\n", filepath);

    // Get the file size
    struct stat st;
    if (fstat(file, &st) == -1) {
        perror("DEBUG: Error getting file size");
        close(file);
        return;
    }
    long filesize = st.st_size;
    printf("DEBUG: File size: %ld bytes\n", filesize);

    // Send the file size to the client
    snprintf(buffer, sizeof(buffer), "%ld\n", filesize);
    send(client_socket, buffer, strlen(buffer), 0);

    // Send the file data to the client
    long total_bytes_sent = 0;
    while (total_bytes_sent < filesize) {
        int bytes_to_read = read(file, buffer, BUFFER_SIZE);
        if (bytes_to_read <= 0) {
            break;
        }
        send(client_socket, buffer, bytes_to_read, 0);
        total_bytes_sent += bytes_to_read;
        printf("DEBUG: Sent %d bytes to client\n", bytes_to_read);
    }

    close(file);
    printf("DEBUG: File transfer complete: %s\n", filename);
}

// Function to handle client commands
void handle_client(int client_socket) {
    char command[BUFFER_SIZE] = {0};

    while (1) {
        // Receive command from client
        int bytes_received = read_line(client_socket, command, BUFFER_SIZE);
        if (bytes_received <= 0) {
            printf("DEBUG: Client disconnected or error\n");
            break;
        }

        printf("DEBUG: Received command: %s\n", command);

        if (strncmp(command, "LIST", 4) == 0) {
            list_files(client_socket);
        } else if (strncmp(command, "UPLOAD", 6) == 0) {
            printf("DEBUG: Recognized UPLOAD command\n");
            upload_file(client_socket);
        } else if (strncmp(command, "DOWNLOAD", 8) == 0) {
            printf("DEBUG: Recognized DOWNLOAD command\n");
            download_file(client_socket);
        } else if (strncmp(command, "QUIT", 4) == 0) {
            printf("DEBUG: Client requested to quit\n");
            break;
        } else {
            const char *error_msg = "Invalid command.\n";
            send(client_socket, error_msg, strlen(error_msg), 0);
        }
    }

    close(client_socket);
}
