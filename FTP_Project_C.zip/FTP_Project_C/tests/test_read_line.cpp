// test_read_line.cpp

#include <gtest/gtest.h>
#include "../server/server_functions.h"

TEST(ReadLineTest, BasicInput) {
    const char *test_input = "Hello, World!\nThis is a test.\n";
    FILE *fp = fmemopen((void *)test_input, strlen(test_input), "r");
    char buffer[BUFFER_SIZE];

    // Test first line
    int bytes_read = read_line_file(fp, buffer, BUFFER_SIZE);
    ASSERT_GT(bytes_read, 0);
    ASSERT_STREQ(buffer, "Hello, World!");

    // Test second line
    bytes_read = read_line_file(fp, buffer, BUFFER_SIZE);
    ASSERT_GT(bytes_read, 0);
    ASSERT_STREQ(buffer, "This is a test.");

    // Test EOF
    bytes_read = read_line_file(fp, buffer, BUFFER_SIZE);
    ASSERT_EQ(bytes_read, -1);

    fclose(fp);
}
