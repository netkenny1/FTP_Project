// client.c

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/stat.h>

#define PORT 2121
#define BUFFER_SIZE 1024

// Function to read a line from the socket
int read_line(int socket, char *buffer, int size) {
    int total_bytes = 0;
    while (total_bytes < size - 1) {
        char c;
        int bytes_received = recv(socket, &c, 1, 0);
        if (bytes_received <= 0) {
            if (total_bytes == 0) {
                return bytes_received;
            } else {
                break;
            }
        }
        if (c == '\n') {
            break;
        }
        buffer[total_bytes++] = c;
    }
    buffer[total_bytes] = '\0';
    return total_bytes;
}

// Function to send a file to the server
void upload_file(int socket) {
    char filename[BUFFER_SIZE] = {0};
    char buffer[BUFFER_SIZE] = {0};
    FILE *file;

    printf("Enter the filename to upload: ");
    fgets(filename, BUFFER_SIZE, stdin);
    filename[strcspn(filename, "\n")] = '\0'; // Remove trailing newline

    // Check if the file exists
    if (access(filename, F_OK) != 0) {
        printf("DEBUG: File does not exist: %s\n", filename);
        return;
    }

    printf("DEBUG: Sending UPLOAD command to server\n");
    send(socket, "UPLOAD\n", 7, 0); // Send the UPLOAD command with newline

    printf("DEBUG: Sending filename: %s\n", filename);
    send(socket, filename, strlen(filename), 0);
    send(socket, "\n", 1, 0); // Send newline to delimit the filename

    // Open the file
    file = fopen(filename, "rb");
    if (file == NULL) {
        perror("DEBUG: Error opening file");
        return;
    }

    // Get the file size
    struct stat st;
    if (stat(filename, &st) == -1) {
        perror("DEBUG: Error getting file size");
        fclose(file);
        return;
    }
    long filesize = st.st_size;
    printf("DEBUG: File size: %ld bytes\n", filesize);

    // Send the file size
    sprintf(buffer, "%ld\n", filesize);
    send(socket, buffer, strlen(buffer), 0);

    printf("DEBUG: Sending file data...\n");
    while (!feof(file)) {
        int bytes_read = fread(buffer, 1, BUFFER_SIZE, file);
        if (bytes_read > 0) {
            send(socket, buffer, bytes_read, 0);
        }
    }

    fclose(file);
    printf("DEBUG: File upload complete, awaiting server confirmation...\n");

    // Wait for confirmation from the server
    int bytes_received = read_line(socket, buffer, BUFFER_SIZE);
    if (bytes_received > 0) {
        printf("DEBUG: Confirmation from server: %s\n", buffer);
    } else {
        printf("DEBUG: No confirmation received from server\n");
    }
}

// Function to receive a file from the server
void download_file(int socket) {
    char filename[BUFFER_SIZE] = {0};
    char buffer[BUFFER_SIZE] = {0};
    FILE *file;

    printf("Enter the filename to download: ");
    fgets(filename, BUFFER_SIZE, stdin);
    filename[strcspn(filename, "\n")] = '\0'; // Remove trailing newline

    printf("DEBUG: Sending DOWNLOAD command to server\n");
    send(socket, "DOWNLOAD\n", 9, 0); // Send the DOWNLOAD command with newline

    printf("DEBUG: Sending filename: %s\n", filename);
    send(socket, filename, strlen(filename), 0);
    send(socket, "\n", 1, 0); // Send newline to delimit the filename

    // Wait for the file size from the server
    if (read_line(socket, buffer, BUFFER_SIZE) <= 0) {
        printf("DEBUG: Failed to receive file size\n");
        return;
    }
    long filesize = atol(buffer);
    if (filesize == 0) {
        printf("DEBUG: File not found on server or empty file\n");
        return;
    }
    printf("DEBUG: File size: %ld bytes\n", filesize);

    // Open the file for writing
    file = fopen(filename, "wb");
    if (file == NULL) {
        perror("DEBUG: Error creating file");
        return;
    }

    // Receive the file data from the server
    long total_bytes_received = 0;
    printf("DEBUG: Receiving file data...\n");
    while (total_bytes_received < filesize) {
        int bytes_to_read = BUFFER_SIZE;
        if (filesize - total_bytes_received < BUFFER_SIZE) {
            bytes_to_read = filesize - total_bytes_received;
        }
        int bytes_received = recv(socket, buffer, bytes_to_read, 0);
        if (bytes_received <= 0) {
            printf("DEBUG: Connection closed or error\n");
            break;
        }
        fwrite(buffer, 1, bytes_received, file);
        total_bytes_received += bytes_received;
        printf("DEBUG: Received %d bytes\n", bytes_received);
    }

    fclose(file);
    printf("DEBUG: File download complete\n");
}

// Function to send a command to the server and display the response
void send_command(int socket, const char *command) {
    char buffer[BUFFER_SIZE] = {0};

    // Send the command to the server
    send(socket, command, strlen(command), 0);
    send(socket, "\n", 1, 0); // Send newline to delimit the command

    // Receive the response from the server
    int bytes_received = recv(socket, buffer, BUFFER_SIZE - 1, 0);
    if (bytes_received > 0) {
        buffer[bytes_received] = '\0';
        printf("Server response:\n%s", buffer);
    } else {
        printf("DEBUG: No response received from server\n");
    }
}

int main() {
    int client_socket;
    struct sockaddr_in server_addr;

    // Create a socket
    client_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (client_socket < 0) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    // Set up the server address
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    // Connect to localhost
    if (inet_pton(AF_INET, "127.0.0.1", &server_addr.sin_addr) <= 0) {
        printf("Invalid address\n");
        return -1;
    }

    // Connect to the server
    if (connect(client_socket, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Connection to server failed");
        close(client_socket);
        exit(EXIT_FAILURE);
    }

    printf("Connected to the server.\n");

    // Main command loop
    while (1) {
        char command[BUFFER_SIZE] = {0};
        printf("ftp> ");
        fgets(command, BUFFER_SIZE, stdin);
        command[strcspn(command, "\n")] = '\0'; // Remove trailing newline

        // Handle commands
        if (strncmp(command, "LIST", 4) == 0) {
            strcat(command, "\n"); // Append newline
            send_command(client_socket, command);
        } else if (strncmp(command, "UPLOAD", 6) == 0) {
            upload_file(client_socket);
        } else if (strncmp(command, "DOWNLOAD", 8) == 0) {
            download_file(client_socket);
        } else if (strncmp(command, "QUIT", 4) == 0) {
            send(client_socket, "QUIT\n", 5, 0);
            break;
        } else {
            printf("Invalid command.\n");
        }
    }

    // Disconnect from the server
    close(client_socket);
    printf("Disconnected from the server.\n");

    return 0;
}
